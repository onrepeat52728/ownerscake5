### DEVELHOPE - FullStack 7 - Team 2
# A PancakeSwap website clone 🥞

The project consists in creating a clone of [PancakeSwap](https://pancakeswap.finance) website.

Take a look at the [preview](https://nico-barbieri.github.io/develhope-pancakeswap-clone/).
